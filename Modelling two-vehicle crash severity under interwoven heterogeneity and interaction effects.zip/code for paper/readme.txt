This repository contains the Python implementation of the multi-tree based SHAP analysis presented in the paper:

"Modelling two-vehicle crash severity under interwoven heterogeneity and interaction effects: A reliability and system safety perspective"

The code is written in Python 3.11 and includes scripts for model estimation, result analysis, and visualization as discussed in the study.

**Repository Contents

   --Machine learning models and SHAP for crash features analysis.

   --Visualization utilities for results.

**Requirements

    --Python 3.11.

    --Libraries: pandas, numpy, scikit-learn, matplotlib (see requirements.txt for full list).

**Related Paper

    --For detailed methodology, theoretical background, and empirical findings, please refer to the full paper.